import streamlit as st
import pandas as pd
import re
import io
import csv

st.title("CSV Data Cleaner & Processor")

uploaded_file = st.file_uploader("Upload your CSV file", type=["csv"])

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)

    st.success("File uploaded successfully!")

    # 🔹 Clean column names
    df.columns = [
        re.sub(r'[^A-Za-z0-9]+', '_', col).strip('_')
        for col in df.columns
    ]

    # 🔹 Remove duplicates
    before = len(df)
    df = df.drop_duplicates()
    after = len(df)
    st.write(f"Duplicates removed: {before - after}")

    # 🔹 Remove newline characters
    df = df.applymap(
        lambda x: re.sub(r'[\n\r]+', ' ', str(x)) if isinstance(x, str) else x
    )

    # 🔹 Data summary
    st.subheader("Data Summary")
    st.write(f"Total records after cleaning: {len(df)}")

    # 🔹 File name input
    output_file_name = st.text_input(
        "Enter output file name (without extension)",
        value="processed_file"
    )

    # 🔹 Prepare CSV ONLY when filename exists
    if output_file_name:
        buffer = io.StringIO()

        df.to_csv(
            buffer,
            sep='|',
            index=False,
            quoting=csv.QUOTE_ALL
        )

        # ✅ IMPORTANT: reset pointer
        buffer.seek(0)

        csv_data = buffer.getvalue()

        # 🔹 Download button
        st.download_button(
            label="Download Processed CSV",
            data=csv_data,
            file_name=f"{output_file_name}.csv",
            mime="text/csv"
        )
    else:
        st.warning("Please enter a valid file name to enable download.")

    # 🔹 Preview
    st.subheader("Preview")
    st.dataframe(df.head(50))